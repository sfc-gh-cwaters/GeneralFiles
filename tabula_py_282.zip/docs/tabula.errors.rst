tabula.errors
=====================

.. automodule:: tabula.errors
   :members:
   :undoc-members:
   :show-inheritance:
