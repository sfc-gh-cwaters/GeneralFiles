tabula
======


.. _high-level-interface:

High level interfaces
----------------------

tabula.io
^^^^^^^^^^^^^^^^^^^^

.. automodule:: tabula.io
   :members:
   :undoc-members:
   :show-inheritance:

tabula.util
^^^^^^^^^^^^^^^

.. automodule:: tabula.util
   :members:
   :undoc-members:
   :show-inheritance:


Internal interfaces
----------------------

tabula.template
^^^^^^^^^^^^^^^^^

.. automodule:: tabula.template
   :members:
   :undoc-members:
   :show-inheritance:


tabula.file\_util
^^^^^^^^^^^^^^^^^^

.. automodule:: tabula.file_util
   :members:
   :undoc-members:
   :show-inheritance:
